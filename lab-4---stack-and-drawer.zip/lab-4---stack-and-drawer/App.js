//BSCS 3-2
//Lumactod, Ian Nino
//So, Jhon Carl
//Tagare, John Christian

import React from "react";
import Navigation from './Routes/Mainstack';




export default function App() {
  return (
    <Navigation />
  );
}